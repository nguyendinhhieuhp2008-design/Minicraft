# Mega TNT (NeoForge 1.21.1)

Mod gồm **30 loại TNT**, mỗi loại có texture, công thức và hiệu ứng riêng. Danh sách đầy đủ: xem `TNT_LIST.md`.

- Minecraft Java **1.21.1**, **NeoForge 21.1.x**, Java 21
- Chạy được trên điện thoại qua PojavLauncher / Zalith / FCL (chọn NeoForge 1.21.1)

## Build ra file .jar bằng điện thoại (GitHub Actions, miễn phí)

1. Tạo tài khoản GitHub, tạo repo mới (private cũng được).
2. Tải toàn bộ nội dung thư mục này lên repo (nút *Add file → Upload files*; nhớ giữ cả thư mục `.github`).
3. Vào tab **Actions**, chọn workflow **Build mod**, bấm **Run workflow** (hoặc tự chạy sau khi upload).
4. Khi chạy xong (khoảng 3-6 phút), mở lần chạy đó, mục **Artifacts** chọn `megatnt-jar` để tải.
   File zip tải về chứa `megatnt-1.0.0.jar` — bỏ file jar vào thư mục `mods`.

## Build trên máy tính

Cần JDK 21 và Gradle 8.10+:

```
gradle build
```

File jar nằm ở `build/libs/megatnt-1.0.0.jar`.

## Tối ưu cho điện thoại

Sau lần chạy đầu sẽ có `config/megatnt-common.toml`:

| Tùy chọn | Mặc định | Ý nghĩa |
|---|---|---|
| `sizeMultiplier` | 1.0 | Nhân kích thước mọi vụ nổ. Máy yếu: 0.5 hoặc 0.25 |
| `blocksPerTick` | 300 | Số block đổi mỗi tick. Giảm nếu bị giật |
| `maxSpawnedEntities` | 24 | Giới hạn thực thể sinh ra mỗi vụ nổ |
| `extraParticles` | true | Tắt để giảm hiệu ứng hạt |

Các vụ nổ lớn (Hạt Nhân, San Phẳng, Đào Hầm...) phá block dần theo từng tick thay vì một lần, nên không bị đứng game.

## Châm ngòi

Bật lửa / quả cầu lửa, redstone, lửa lan, tên lửa cháy, hoặc nổ dây chuyền từ TNT khác.
