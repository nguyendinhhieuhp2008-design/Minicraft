# 30 loại TNT

Tất cả đều cần 1 TNT thường ở ô giữa (trừ Mini và Chùm, xem cột công thức; `T` = TNT thường).

| # | Tên (EN) | Tên (VI) | Hiệu ứng | Nguyên liệu | Hình dạng |
|---|---|---|---|---|---|
| 1 | Mini TNT | TNT Mini | Small, cheap blast. | Gunpowder | `GG / GG` |
| 2 | Big TNT | TNT Lớn | A solid, bigger blast. | Gunpowder | `III / ITI / III` |
| 3 | Mega TNT | TNT Siêu Lớn | Huge crater-maker. | Big Tnt | `III / ITI / III` |
| 4 | Nuclear TNT | TNT Hạt Nhân | Erases a giant sphere of terrain. | Diamond, Mega Tnt, Nether Star | `MDM / DND / MDM` |
| 5 | Inferno TNT | TNT Lửa | Sets everything ablaze. | Blaze Powder | `III / ITI / III` |
| 6 | Frost TNT | TNT Băng | Freezes water, cools lava, covers land in snow. | Packed Ice | `III / ITI / III` |
| 7 | Thunder TNT | TNT Sấm Sét | Calls down lightning bolts. | Lightning Rod | ` I  / ITI /  I ` |
| 8 | Skyrocket TNT | TNT Bay Lên | Launches everything nearby skyward (with slow falling). | Feather | `I I /  T  / I I` |
| 9 | Black Hole TNT | TNT Hố Đen | Pulls everything in, then devours the center. | Ender Pearl, Obsidian | `OPO / PTP / OPO` |
| 10 | Flood TNT | TNT Nước | Floods the area with water. | Wet Sponge | ` I  / ITI /  I ` |
| 11 | Magma TNT | TNT Dung Nham | Scatters pools of lava. | Magma Block | ` I  / ITI /  I ` |
| 12 | Dirt TNT | TNT Đất | Turns the terrain into dirt. | Dirt | `III / ITI / III` |
| 13 | Ore TNT | TNT Quặng | Seeds nearby stone with ores. Harmless! | Coal, Gold Ingot, Iron Ingot, Lapis Lazuli, Redstone | `ICG / LTR / GCI` |
| 14 | Treasure TNT | TNT Kho Báu | Bursts into loot instead of destruction. | Gold Ingot | `III / ITI / III` |
| 15 | Cobweb TNT | TNT Mạng Nhện | Fills the air with cobwebs. | String | `III / ITI / III` |
| 16 | Slime TNT | TNT Slime | Bounces everyone up and spawns slimes. | Slime Ball | `III / ITI / III` |
| 17 | Toxic TNT | TNT Độc | Leaves a cloud of poison. | Spider Eye | `III / ITI / III` |
| 18 | Healing TNT | TNT Hồi Máu | Heals and gives regeneration. | Glistering Melon Slice | `III / ITI / III` |
| 19 | Darkness TNT | TNT Bóng Tối | Cloud of blindness and darkness. | Ink Sac | `III / ITI / III` |
| 20 | Nature TNT | TNT Thiên Nhiên | Grows grass, flowers, crops and trees. | Bone Meal | `III / ITI / III` |
| 21 | Shaft TNT | TNT Đào Hầm | Drills a shaft straight down to bedrock. | Iron Pickaxe | ` I  / ITI /  I ` |
| 22 | Cluster TNT | TNT Chùm | Splits into many mini TNTs. | TNT | `TTT / TTT / TTT` |
| 23 | Airstrike TNT | TNT Không Kích | Rains mini TNTs from the sky. | Arrow | `III / ITI / III` |
| 24 | Teleport TNT | TNT Dịch Chuyển | Scatters nearby creatures far away. | Ender Eye | `III / ITI / III` |
| 25 | Firework TNT | TNT Pháo Hoa | A colorful, harmless light show. | Firework Rocket | `III / ITI / III` |
| 26 | Shockwave TNT | TNT Sóng Xung Kích | Blasts entities away without breaking blocks. | Piston | `I I /  T  / I I` |
| 27 | Dome TNT | TNT Mái Vòm | Builds a glass dome around the blast. | Glass | `III / ITI / III` |
| 28 | Leveler TNT | TNT San Phẳng | Flattens everything above its height. | Iron Shovel | ` I  / ITI /  I ` |
| 29 | Sandstorm TNT | TNT Bão Cát | Rains sand and gravel from above. | Sand | `III / ITI / III` |
| 30 | Chaos TNT | TNT Hỗn Loạn | Triggers a random effect from another TNT. | Chorus Fruit, Nether Wart | `CNC / NTN / CNC` |
