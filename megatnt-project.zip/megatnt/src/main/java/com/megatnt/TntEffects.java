package com.megatnt;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

import it.unimi.dsi.fastutil.ints.IntArrayList;

import org.jetbrains.annotations.Nullable;

import net.minecraft.core.BlockPos;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.AreaEffectCloud;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.item.FallingBlockEntity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.monster.Slime;
import net.minecraft.world.entity.projectile.FireworkRocketEntity;
import net.minecraft.world.item.BoneMealItem;
import net.minecraft.world.item.DyeColor;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.component.FireworkExplosion;
import net.minecraft.world.item.component.Fireworks;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/**
 * What each TNT does when it explodes. Block changes go through {@link BlockQueue} so big
 * effects are spread over several ticks (phone friendly). Sizes scale with Config.SIZE.
 */
public final class TntEffects {
    private static final Block[] ORES = {Blocks.COAL_ORE, Blocks.IRON_ORE, Blocks.COPPER_ORE, Blocks.GOLD_ORE,
            Blocks.REDSTONE_ORE, Blocks.LAPIS_ORE, Blocks.DIAMOND_ORE, Blocks.EMERALD_ORE};
    private static final Block[] DEEP_ORES = {Blocks.DEEPSLATE_COAL_ORE, Blocks.DEEPSLATE_IRON_ORE,
            Blocks.DEEPSLATE_COPPER_ORE, Blocks.DEEPSLATE_GOLD_ORE, Blocks.DEEPSLATE_REDSTONE_ORE,
            Blocks.DEEPSLATE_LAPIS_ORE, Blocks.DEEPSLATE_DIAMOND_ORE, Blocks.DEEPSLATE_EMERALD_ORE};
    private static final Block[] SAPLINGS = {Blocks.OAK_SAPLING, Blocks.BIRCH_SAPLING, Blocks.SPRUCE_SAPLING,
            Blocks.ACACIA_SAPLING, Blocks.CHERRY_SAPLING};
    private static final Block[] FALLING = {Blocks.SAND, Blocks.RED_SAND, Blocks.GRAVEL};

    private TntEffects() {
    }

    // ------------------------------------------------------------------ helpers

    private static float size() {
        return Config.SIZE.get().floatValue();
    }

    /** Scales a radius/count by the size multiplier (never below 1). */
    private static int s(double value) {
        return Math.max(1, (int) Math.round(value * Config.SIZE.get()));
    }

    private static int cap(int n) {
        return Math.min(n, Config.MAX_ENTITIES.get());
    }

    private static List<BlockPos> sphere(BlockPos c, int radius) {
        int r = Math.min(radius, 40);
        int r2 = r * r;
        List<BlockPos> out = new ArrayList<>();
        for (int x = -r; x <= r; x++) {
            for (int y = -r; y <= r; y++) {
                for (int z = -r; z <= r; z++) {
                    if (x * x + y * y + z * z <= r2) {
                        out.add(c.offset(x, y, z));
                    }
                }
            }
        }
        out.sort(Comparator.comparingDouble(p -> p.distSqr(c)));
        return out;
    }

    private static boolean breakable(ServerLevel level, BlockPos p) {
        if (!level.hasChunkAt(p)) {
            return false;
        }
        BlockState st = level.getBlockState(p);
        return !st.isAir() && st.getDestroySpeed(level, p) >= 0;
    }

    private static boolean canReplace(ServerLevel level, BlockPos p) {
        if (!level.hasChunkAt(p)) {
            return false;
        }
        BlockState st = level.getBlockState(p);
        return st.isAir() || (st.is(BlockTags.REPLACEABLE) && !st.is(Blocks.WATER) && !st.is(Blocks.LAVA));
    }

    private static void air(ServerLevel level, BlockPos p) {
        BlockQueue.add(level, p, Blocks.AIR.defaultBlockState());
    }

    /** Explosion sound + particles without any damage or block change. */
    private static void boom(ServerLevel level, double x, double y, double z) {
        level.explode(null, x, y, z, 0.0F, Level.ExplosionInteraction.NONE);
    }

    private static void particles(ServerLevel level, ParticleOptions type, double x, double y, double z, int count,
                                  double dx, double dy, double dz, double speed) {
        if (Config.PARTICLES.get()) {
            level.sendParticles(type, x, y, z, count, dx, dy, dz, speed);
        }
    }

    private static List<LivingEntity> living(ServerLevel level, Vec3 center, double r) {
        return level.getEntitiesOfClass(LivingEntity.class, AABB.ofSize(center, r * 2, r * 2, r * 2),
                e -> e.position().distanceToSqr(center) <= r * r);
    }

    private static List<Entity> everything(ServerLevel level, Vec3 center, double r) {
        return level.getEntities((Entity) null, AABB.ofSize(center, r * 2, r * 2, r * 2),
                e -> e.position().distanceToSqr(center) <= r * r);
    }

    private static void hurt(ServerLevel level, Entity src, @Nullable LivingEntity owner, Vec3 center, double r, float max) {
        DamageSource ds = level.damageSources().explosion(src, owner);
        for (LivingEntity e : living(level, center, r)) {
            double d = e.position().distanceTo(center);
            e.hurt(ds, (float) (max * (1.0D - d / r)));
        }
    }

    private static void launch(Entity e, double x, double y, double z) {
        e.setDeltaMovement(e.getDeltaMovement().add(x, y, z));
        e.hurtMarked = true;
    }

    private static void cloud(ServerLevel level, double x, double y, double z, @Nullable LivingEntity owner, int color,
                              float radius, int duration, MobEffectInstance... effects) {
        float r = radius * size();
        AreaEffectCloud cloud = new AreaEffectCloud(level, x, y, z);
        cloud.setOwner(owner);
        cloud.setRadius(r);
        cloud.setDuration(duration);
        cloud.setWaitTime(5);
        cloud.setRadiusPerTick(-r / duration);
        cloud.setFixedColor(color);
        for (MobEffectInstance effect : effects) {
            cloud.addEffect(effect);
        }
        level.addFreshEntity(cloud);
    }

    // ------------------------------------------------------------------ dispatcher

    public static void detonate(TntType type, ServerLevel level, double x, double y, double z, Entity src,
                                @Nullable LivingEntity owner) {
        BlockPos c = BlockPos.containing(x, y, z);
        Vec3 ctr = new Vec3(x, y, z);
        RandomSource rnd = level.random;

        switch (type) {
            case MINI -> level.explode(src, x, y, z, 2.0F * size(), Level.ExplosionInteraction.TNT);
            case BIG -> level.explode(src, x, y, z, 6.0F * size(), Level.ExplosionInteraction.TNT);
            case MEGA -> level.explode(src, x, y, z, 9.0F * size(), Level.ExplosionInteraction.TNT);

            case NUCLEAR -> {
                int r = s(20);
                for (BlockPos p : sphere(c, r)) {
                    if (breakable(level, p)) {
                        air(level, p);
                    }
                }
                hurt(level, src, owner, ctr, r * 1.5D, 60.0F);
                for (Entity e : everything(level, ctr, r * 1.5D)) {
                    Vec3 d = e.position().subtract(ctr).normalize();
                    launch(e, d.x * 2.0D, 0.8D, d.z * 2.0D);
                }
                boom(level, x, y, z);
                particles(level, ParticleTypes.EXPLOSION_EMITTER, x, y, z, 6, r * 0.3D, r * 0.15D, r * 0.3D, 0);
            }

            case FIRE -> {
                level.explode(src, x, y, z, 3.0F * size(), true, Level.ExplosionInteraction.TNT);
                int r = s(8);
                BlockState fire = Blocks.FIRE.defaultBlockState();
                for (BlockPos p : sphere(c, r)) {
                    if (level.hasChunkAt(p) && level.getBlockState(p).isAir() && fire.canSurvive(level, p)
                            && rnd.nextFloat() < 0.35F) {
                        BlockQueue.add(level, p, fire);
                    }
                }
                for (LivingEntity e : living(level, ctr, r)) {
                    e.setRemainingFireTicks(160);
                }
                particles(level, ParticleTypes.FLAME, x, y + 1, z, 80, r * 0.4D, 1.0D, r * 0.4D, 0.05D);
            }

            case ICE -> {
                int r = s(9);
                for (BlockPos p : sphere(c, r)) {
                    if (!level.hasChunkAt(p)) {
                        continue;
                    }
                    BlockState st = level.getBlockState(p);
                    if (st.is(Blocks.WATER)) {
                        BlockQueue.add(level, p, Blocks.ICE.defaultBlockState());
                    } else if (st.is(Blocks.LAVA)) {
                        BlockQueue.add(level, p, Blocks.OBSIDIAN.defaultBlockState());
                    } else if (st.isAir() && level.getBlockState(p.below()).isFaceSturdy(level, p.below(), net.minecraft.core.Direction.UP)
                            && rnd.nextFloat() < 0.6F) {
                        BlockQueue.add(level, p, Blocks.SNOW.defaultBlockState());
                    }
                }
                for (LivingEntity e : living(level, ctr, r)) {
                    e.setTicksFrozen(300);
                    e.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 200, 2));
                }
                boom(level, x, y, z);
                particles(level, ParticleTypes.SNOWFLAKE, x, y + 1, z, 120, r * 0.4D, 1.0D, r * 0.4D, 0.05D);
            }

            case LIGHTNING -> {
                int n = cap(s(10));
                int r = s(14);
                for (int i = 0; i < n; i++) {
                    int bx = c.getX() + Mth.nextInt(rnd, -r, r);
                    int bz = c.getZ() + Mth.nextInt(rnd, -r, r);
                    if (!level.hasChunkAt(new BlockPos(bx, c.getY(), bz))) {
                        continue;
                    }
                    BlockPos top = new BlockPos(bx, level.getHeight(Heightmap.Types.MOTION_BLOCKING, bx, bz), bz);
                    LightningBolt bolt = EntityType.LIGHTNING_BOLT.create(level);
                    if (bolt != null) {
                        bolt.moveTo(Vec3.atBottomCenterOf(top));
                        bolt.setCause(owner instanceof ServerPlayer sp ? sp : null);
                        level.addFreshEntity(bolt);
                    }
                }
                level.explode(src, x, y, z, 2.0F * size(), Level.ExplosionInteraction.TNT);
            }

            case SKY -> {
                int r = s(12);
                for (Entity e : everything(level, ctr, r)) {
                    launch(e, 0.0D, 3.2D, 0.0D);
                    if (e instanceof LivingEntity le) {
                        le.addEffect(new MobEffectInstance(MobEffects.SLOW_FALLING, 300, 0));
                    }
                }
                boom(level, x, y, z);
                particles(level, ParticleTypes.CLOUD, x, y + 0.5D, z, 80, 1.5D, 0.3D, 1.5D, 0.2D);
            }

            case BLACKHOLE -> {
                int r = s(7);
                double pull = s(26);
                for (Entity e : everything(level, ctr, pull)) {
                    Vec3 d = ctr.subtract(e.position());
                    double len = d.length();
                    if (len < 0.5D) {
                        continue;
                    }
                    e.setDeltaMovement(d.normalize().scale(Math.min(2.5D, 6.0D / len + 0.5D)));
                    e.hurtMarked = true;
                }
                for (BlockPos p : sphere(c, r)) {
                    if (breakable(level, p)) {
                        air(level, p);
                    }
                }
                hurt(level, src, owner, ctr, r, 30.0F);
                boom(level, x, y, z);
                particles(level, ParticleTypes.PORTAL, x, y + 1, z, 200, r * 0.5D, r * 0.5D, r * 0.5D, 1.0D);
                particles(level, ParticleTypes.SQUID_INK, x, y + 1, z, 60, r * 0.3D, r * 0.3D, r * 0.3D, 0.1D);
            }

            case WATER -> {
                int r = s(6);
                BlockState water = Blocks.WATER.defaultBlockState();
                for (BlockPos p : sphere(c, r)) {
                    if (canReplace(level, p)) {
                        BlockQueue.add(level, p, water);
                    }
                }
                for (LivingEntity e : living(level, ctr, r)) {
                    e.clearFire();
                }
                boom(level, x, y, z);
                particles(level, ParticleTypes.SPLASH, x, y + 1, z, 150, r * 0.4D, 1.0D, r * 0.4D, 0.2D);
            }

            case LAVA -> {
                int r = s(5);
                BlockState lava = Blocks.LAVA.defaultBlockState();
                for (BlockPos p : sphere(c, r)) {
                    if (canReplace(level, p) && rnd.nextFloat() < 0.3F) {
                        BlockQueue.add(level, p, lava);
                    }
                }
                for (LivingEntity e : living(level, ctr, r)) {
                    e.setRemainingFireTicks(120);
                }
                boom(level, x, y, z);
                particles(level, ParticleTypes.LAVA, x, y + 1, z, 60, r * 0.4D, 1.0D, r * 0.4D, 0.1D);
            }

            case DIRT -> {
                int r = s(7);
                for (BlockPos p : sphere(c, r)) {
                    if (breakable(level, p) && level.getBlockState(p).getFluidState().isEmpty()
                            && level.getBlockEntity(p) == null && !level.getBlockState(p).is(Blocks.DIRT)) {
                        BlockQueue.add(level, p, (rnd.nextFloat() < 0.15F ? Blocks.COARSE_DIRT : Blocks.DIRT).defaultBlockState());
                    }
                }
                boom(level, x, y, z);
                particles(level, ParticleTypes.POOF, x, y + 1, z, 40, r * 0.3D, 0.5D, r * 0.3D, 0.1D);
            }

            case ORE -> {
                int r = s(10);
                for (BlockPos p : sphere(c, r)) {
                    if (!level.hasChunkAt(p)) {
                        continue;
                    }
                    BlockState st = level.getBlockState(p);
                    if (st.is(BlockTags.BASE_STONE_OVERWORLD) && rnd.nextFloat() < 0.12F) {
                        int roll = rnd.nextInt(100);
                        int idx = roll < 30 ? 0 : roll < 55 ? 1 : roll < 70 ? 2 : roll < 80 ? 3
                                : roll < 90 ? 4 : roll < 95 ? 5 : roll < 99 ? 6 : 7;
                        boolean deep = st.is(Blocks.DEEPSLATE) || p.getY() < 0;
                        BlockQueue.add(level, p, (deep ? DEEP_ORES : ORES)[idx].defaultBlockState());
                    }
                }
                boom(level, x, y, z);
                particles(level, ParticleTypes.HAPPY_VILLAGER, x, y + 1, z, 60, r * 0.3D, r * 0.3D, r * 0.3D, 0.1D);
            }

            case TREASURE -> {
                int n = cap(s(18));
                for (int i = 0; i < n; i++) {
                    ItemEntity item = new ItemEntity(level, x, y + 0.5D, z, randomLoot(rnd),
                            (rnd.nextDouble() - 0.5D) * 0.6D, 0.4D + rnd.nextDouble() * 0.4D, (rnd.nextDouble() - 0.5D) * 0.6D);
                    level.addFreshEntity(item);
                }
                boom(level, x, y, z);
                particles(level, ParticleTypes.TOTEM_OF_UNDYING, x, y + 1, z, 60, 1.0D, 1.0D, 1.0D, 0.4D);
            }

            case COBWEB -> {
                int r = s(6);
                BlockState web = Blocks.COBWEB.defaultBlockState();
                for (BlockPos p : sphere(c, r)) {
                    if (canReplace(level, p) && rnd.nextFloat() < 0.65F) {
                        BlockQueue.add(level, p, web);
                    }
                }
                boom(level, x, y, z);
            }

            case SLIME -> {
                int r = s(10);
                for (LivingEntity e : living(level, ctr, r)) {
                    launch(e, 0.0D, 1.6D, 0.0D);
                    e.addEffect(new MobEffectInstance(MobEffects.JUMP, 300, 3));
                }
                int n = cap(s(6));
                for (int i = 0; i < n; i++) {
                    Slime slime = EntityType.SLIME.create(level);
                    if (slime != null) {
                        slime.setSize(1 + rnd.nextInt(2), true);
                        slime.moveTo(x, y + 0.5D, z, rnd.nextFloat() * 360.0F, 0.0F);
                        slime.setDeltaMovement((rnd.nextDouble() - 0.5D) * 0.8D, 0.5D, (rnd.nextDouble() - 0.5D) * 0.8D);
                        level.addFreshEntity(slime);
                    }
                }
                boom(level, x, y, z);
                particles(level, ParticleTypes.ITEM_SLIME, x, y + 1, z, 80, 1.5D, 1.0D, 1.5D, 0.2D);
            }

            case POISON -> {
                cloud(level, x, y, z, owner, 0x4E9331, 6.0F, 300, new MobEffectInstance(MobEffects.POISON, 200, 1));
                boom(level, x, y, z);
            }

            case HEALING -> {
                cloud(level, x, y, z, owner, 0xFF69B4, 6.0F, 300,
                        new MobEffectInstance(MobEffects.REGENERATION, 200, 2),
                        new MobEffectInstance(MobEffects.ABSORPTION, 600, 1));
                for (LivingEntity e : living(level, ctr, s(6))) {
                    e.heal(10.0F);
                }
                boom(level, x, y, z);
                particles(level, ParticleTypes.HEART, x, y + 1, z, 30, 2.0D, 1.0D, 2.0D, 0.1D);
            }

            case BLIND -> {
                cloud(level, x, y, z, owner, 0x1A1A1A, 7.0F, 300,
                        new MobEffectInstance(MobEffects.BLINDNESS, 120, 0),
                        new MobEffectInstance(MobEffects.DARKNESS, 300, 0));
                boom(level, x, y, z);
                particles(level, ParticleTypes.LARGE_SMOKE, x, y + 1, z, 60, 2.0D, 1.0D, 2.0D, 0.05D);
            }

            case NATURE -> {
                int r = s(10);
                int saplings = 0;
                for (int dx = -r; dx <= r; dx++) {
                    for (int dz = -r; dz <= r; dz++) {
                        if (dx * dx + dz * dz > r * r) {
                            continue;
                        }
                        for (int dy = -3; dy <= 3; dy++) {
                            BlockPos p = c.offset(dx, dy, dz);
                            if (!level.hasChunkAt(p)) {
                                continue;
                            }
                            BlockState st = level.getBlockState(p);
                            boolean airAbove = level.getBlockState(p.above()).isAir();
                            if (st.is(Blocks.DIRT) && airAbove) {
                                level.setBlock(p, Blocks.GRASS_BLOCK.defaultBlockState(), Block.UPDATE_ALL);
                                st = level.getBlockState(p);
                            }
                            if (st.is(Blocks.GRASS_BLOCK) && airAbove && saplings < 6 && rnd.nextInt(60) == 0) {
                                level.setBlock(p.above(), SAPLINGS[rnd.nextInt(SAPLINGS.length)].defaultBlockState(), Block.UPDATE_ALL);
                                saplings++;
                                for (int k = 0; k < 4; k++) {
                                    BoneMealItem.growCrop(new ItemStack(Items.BONE_MEAL), level, p.above());
                                }
                            } else if (rnd.nextFloat() < 0.35F) {
                                BoneMealItem.growCrop(new ItemStack(Items.BONE_MEAL), level, p);
                            }
                        }
                    }
                }
                boom(level, x, y, z);
                particles(level, ParticleTypes.HAPPY_VILLAGER, x, y + 1, z, 100, r * 0.4D, 1.0D, r * 0.4D, 0.1D);
            }

            case SHAFT -> {
                int r = Math.max(1, s(2));
                int minY = level.getMinBuildHeight();
                for (int yy = c.getY(); yy >= minY; yy--) {
                    for (int dx = -r; dx <= r; dx++) {
                        for (int dz = -r; dz <= r; dz++) {
                            BlockPos p = new BlockPos(c.getX() + dx, yy, c.getZ() + dz);
                            if (breakable(level, p)) {
                                air(level, p);
                            }
                        }
                    }
                }
                boom(level, x, y, z);
                particles(level, ParticleTypes.POOF, x, y, z, 40, 1.0D, 0.5D, 1.0D, 0.1D);
            }

            case CLUSTER -> {
                int n = cap(s(8));
                for (int i = 0; i < n; i++) {
                    double a = rnd.nextDouble() * Math.PI * 2.0D;
                    double sp = 0.3D + rnd.nextDouble() * 0.4D;
                    CustomPrimedTnt.spawn(level, TntType.MINI, x, y + 0.3D, z, owner, 30 + rnd.nextInt(20),
                            Math.cos(a) * sp, 0.5D + rnd.nextDouble() * 0.3D, Math.sin(a) * sp);
                }
                boom(level, x, y, z);
            }

            case AIRSTRIKE -> {
                int n = cap(s(12));
                int r = s(12);
                double py = Math.min(y + 25.0D, level.getMaxBuildHeight() - 2);
                for (int i = 0; i < n; i++) {
                    CustomPrimedTnt.spawn(level, TntType.MINI, x + (rnd.nextDouble() * 2 - 1) * r, py,
                            z + (rnd.nextDouble() * 2 - 1) * r, owner, 60 + rnd.nextInt(30), 0.0D, -0.2D, 0.0D);
                }
                boom(level, x, y, z);
            }

            case TELEPORT -> {
                int range = s(25);
                for (LivingEntity e : living(level, ctr, s(10))) {
                    for (int i = 0; i < 12; i++) {
                        double tx = x + (rnd.nextDouble() * 2 - 1) * range;
                        double ty = y + rnd.nextInt(8) - 3;
                        double tz = z + (rnd.nextDouble() * 2 - 1) * range;
                        if (e.randomTeleport(tx, ty, tz, true)) {
                            break;
                        }
                    }
                }
                level.playSound(null, x, y, z, SoundEvents.ENDERMAN_TELEPORT, SoundSource.BLOCKS, 1.0F, 1.0F);
                particles(level, ParticleTypes.PORTAL, x, y + 1, z, 150, 1.0D, 1.0D, 1.0D, 1.0D);
            }

            case FIREWORK -> {
                int n = cap(s(12));
                int r = s(6);
                for (int i = 0; i < n; i++) {
                    ItemStack rocket = new ItemStack(Items.FIREWORK_ROCKET);
                    rocket.set(DataComponents.FIREWORKS, new Fireworks(1 + rnd.nextInt(2), List.of(randomExplosion(rnd))));
                    level.addFreshEntity(new FireworkRocketEntity(level, x + (rnd.nextDouble() * 2 - 1) * r, y + 0.5D,
                            z + (rnd.nextDouble() * 2 - 1) * r, rocket));
                }
                boom(level, x, y, z);
            }

            case SHOCKWAVE -> {
                int r = s(20);
                DamageSource ds = level.damageSources().explosion(src, owner);
                for (Entity e : everything(level, ctr, r)) {
                    Vec3 d = e.position().subtract(ctr);
                    double len = Math.max(0.5D, d.length());
                    double f = (1.0D - len / r) * 3.0D + 0.4D;
                    Vec3 dir = d.normalize();
                    launch(e, dir.x * f, 0.3D + f * 0.3D, dir.z * f);
                    if (e instanceof LivingEntity le) {
                        le.hurt(ds, (float) (6.0D * (1.0D - len / r)));
                    }
                }
                boom(level, x, y, z);
                particles(level, ParticleTypes.SONIC_BOOM, x, y + 1, z, 1, 0, 0, 0, 0);
                for (int i = 0; i < 36; i++) {
                    double a = i * Math.PI / 18.0D;
                    particles(level, ParticleTypes.POOF, x + Math.cos(a) * 2, y + 0.3D, z + Math.sin(a) * 2, 0,
                            Math.cos(a), 0.05D, Math.sin(a), 1.2D);
                }
            }

            case DOME -> {
                int r = s(7);
                double inner = (r - 1.0D) * (r - 1.0D);
                BlockState glass = Blocks.GLASS.defaultBlockState();
                for (BlockPos p : sphere(c, r)) {
                    if (p.distSqr(c) >= inner && canReplace(level, p)) {
                        BlockQueue.add(level, p, glass);
                    }
                }
                boom(level, x, y, z);
            }

            case LEVELER -> {
                int r = s(12);
                int h = s(30);
                List<BlockPos> list = new ArrayList<>();
                for (int dx = -r; dx <= r; dx++) {
                    for (int dz = -r; dz <= r; dz++) {
                        if (dx * dx + dz * dz > r * r) {
                            continue;
                        }
                        for (int dy = 0; dy <= h; dy++) {
                            list.add(c.offset(dx, dy, dz));
                        }
                    }
                }
                list.sort(Comparator.comparingDouble(p -> p.distSqr(c)));
                for (BlockPos p : list) {
                    if (breakable(level, p)) {
                        air(level, p);
                    }
                }
                boom(level, x, y, z);
                particles(level, ParticleTypes.POOF, x, y + 1, z, 60, r * 0.4D, 0.5D, r * 0.4D, 0.1D);
            }

            case SANDSTORM -> {
                int n = Math.min(s(40), Config.MAX_ENTITIES.get() * 2);
                int r = s(10);
                for (int i = 0; i < n; i++) {
                    BlockPos p = c.offset(Mth.nextInt(rnd, -r, r), 14 + rnd.nextInt(14), Mth.nextInt(rnd, -r, r));
                    if (level.hasChunkAt(p) && level.getBlockState(p).isAir()) {
                        FallingBlockEntity fb = FallingBlockEntity.fall(level, p, FALLING[rnd.nextInt(FALLING.length)].defaultBlockState());
                        fb.setHurtsEntities(2.0F, 40);
                    }
                }
                boom(level, x, y, z);
            }

            case CHAOS -> {
                TntType[] all = TntType.values();
                TntType pick;
                do {
                    pick = all[rnd.nextInt(all.length)];
                } while (pick == TntType.CHAOS || pick == TntType.NUCLEAR);
                if (owner instanceof ServerPlayer sp) {
                    sp.displayClientMessage(Component.literal("Chaos: ").append(Component.translatable("block.megatnt." + pick.id)), true);
                }
                detonate(pick, level, x, y, z, src, owner);
            }

            default -> level.explode(src, x, y, z, 4.0F * size(), Level.ExplosionInteraction.TNT);
        }
    }

    // ------------------------------------------------------------------ random content

    private static ItemStack randomLoot(RandomSource rnd) {
        int roll = rnd.nextInt(100);
        if (roll < 30) {
            return new ItemStack(Items.GOLD_INGOT, 1 + rnd.nextInt(3));
        } else if (roll < 55) {
            return new ItemStack(Items.IRON_INGOT, 1 + rnd.nextInt(4));
        } else if (roll < 70) {
            return new ItemStack(Items.EMERALD, 1 + rnd.nextInt(2));
        } else if (roll < 80) {
            return new ItemStack(Items.EXPERIENCE_BOTTLE, 1 + rnd.nextInt(3));
        } else if (roll < 90) {
            return new ItemStack(Items.DIAMOND, 1);
        } else if (roll < 97) {
            return new ItemStack(Items.GOLDEN_APPLE, 1);
        }
        return new ItemStack(Items.ENCHANTED_GOLDEN_APPLE, 1);
    }

    private static FireworkExplosion randomExplosion(RandomSource rnd) {
        FireworkExplosion.Shape[] shapes = FireworkExplosion.Shape.values();
        DyeColor[] dyes = DyeColor.values();
        IntArrayList colors = new IntArrayList();
        int count = 1 + rnd.nextInt(3);
        for (int i = 0; i < count; i++) {
            colors.add(dyes[rnd.nextInt(dyes.length)].getFireworkColor());
        }
        return new FireworkExplosion(shapes[rnd.nextInt(shapes.length)], colors, new IntArrayList(),
                rnd.nextBoolean(), rnd.nextBoolean());
    }
}
