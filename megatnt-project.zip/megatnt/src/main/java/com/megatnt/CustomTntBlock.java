package com.megatnt;

import com.mojang.serialization.MapCodec;

import org.jetbrains.annotations.Nullable;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.stats.Stats;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.ItemInteractionResult;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Explosion;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;

/**
 * A TNT block. Extends Block directly (not TntBlock) because vanilla TntBlock hard-codes
 * spawning the vanilla primed TNT entity in its static explode() helper.
 */
public class CustomTntBlock extends Block {
    private static final MapCodec<CustomTntBlock> CODEC = simpleCodec(props -> new CustomTntBlock(props, TntType.MINI));

    private final TntType type;

    public CustomTntBlock(Properties properties, TntType type) {
        super(properties);
        this.type = type;
    }

    public TntType getType() {
        return type;
    }

    @Override
    protected MapCodec<? extends Block> codec() {
        return CODEC;
    }

    private void ignite(Level level, BlockPos pos, @Nullable LivingEntity igniter, int fuse) {
        if (!level.isClientSide) {
            CustomPrimedTnt.spawn(level, type, pos.getX() + 0.5D, pos.getY(), pos.getZ() + 0.5D, igniter, fuse,
                    (level.random.nextDouble() - 0.5D) * 0.04D, 0.2D, (level.random.nextDouble() - 0.5D) * 0.04D);
        }
    }

    /** Called by fire / lava / other mods. The caller removes the block. */
    @Override
    public void onCaughtFire(BlockState state, Level level, BlockPos pos, @Nullable Direction face, @Nullable LivingEntity igniter) {
        ignite(level, pos, igniter, type.fuse);
    }

    /** Chain reaction: another explosion blew this block up. */
    @Override
    public void wasExploded(Level level, BlockPos pos, Explosion explosion) {
        if (!level.isClientSide) {
            int fuse = level.random.nextInt(Math.max(1, type.fuse / 4)) + type.fuse / 8;
            ignite(level, pos, explosion.getIndirectSourceEntity(), fuse);
        }
    }

    @Override
    protected void onPlace(BlockState state, Level level, BlockPos pos, BlockState oldState, boolean movedByPiston) {
        if (!oldState.is(state.getBlock()) && level.hasNeighborSignal(pos)) {
            ignite(level, pos, null, type.fuse);
            level.removeBlock(pos, false);
        }
    }

    @Override
    protected void neighborChanged(BlockState state, Level level, BlockPos pos, Block block, BlockPos fromPos, boolean movedByPiston) {
        if (level.hasNeighborSignal(pos)) {
            ignite(level, pos, null, type.fuse);
            level.removeBlock(pos, false);
        }
    }

    @Override
    protected ItemInteractionResult useItemOn(ItemStack stack, BlockState state, Level level, BlockPos pos, Player player,
                                              InteractionHand hand, BlockHitResult hit) {
        if (!stack.is(Items.FLINT_AND_STEEL) && !stack.is(Items.FIRE_CHARGE)) {
            return super.useItemOn(stack, state, level, pos, player, hand, hit);
        }
        ignite(level, pos, player, type.fuse);
        level.setBlock(pos, Blocks.AIR.defaultBlockState(), Block.UPDATE_ALL_IMMEDIATE);
        Item item = stack.getItem();
        if (stack.is(Items.FLINT_AND_STEEL)) {
            stack.hurtAndBreak(1, player, LivingEntity.getSlotForHand(hand));
        } else if (!player.isCreative()) {
            stack.shrink(1);
        }
        player.awardStat(Stats.ITEM_USED.get(item));
        return ItemInteractionResult.sidedSuccess(level.isClientSide);
    }

    /** Flaming arrows light the fuse. */
    @Override
    protected void onProjectileHit(Level level, BlockState state, BlockHitResult hit, Projectile projectile) {
        if (!level.isClientSide) {
            BlockPos pos = hit.getBlockPos();
            Entity owner = projectile.getOwner();
            if (projectile.isOnFire() && projectile.mayInteract(level, pos)) {
                ignite(level, pos, owner instanceof LivingEntity living ? living : null, type.fuse);
                level.removeBlock(pos, false);
            }
        }
    }
}
