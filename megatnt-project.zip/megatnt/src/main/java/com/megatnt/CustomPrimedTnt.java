package com.megatnt;

import org.jetbrains.annotations.Nullable;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.item.PrimedTnt;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;

/**
 * One entity type for all 30 TNTs: the block state it carries decides how it looks
 * (vanilla TntRenderer) and what it does when the fuse ends.
 */
public class CustomPrimedTnt extends PrimedTnt {
    @Nullable
    private LivingEntity igniter;

    public CustomPrimedTnt(EntityType<? extends PrimedTnt> entityType, Level level) {
        super(entityType, level);
    }

    public void configure(BlockState state, int fuse, @Nullable LivingEntity igniter) {
        this.setBlockState(state);
        this.setFuse(fuse);
        this.igniter = igniter;
    }

    public static void spawn(Level level, TntType type, double x, double y, double z, @Nullable LivingEntity owner,
                             int fuse, double vx, double vy, double vz) {
        CustomPrimedTnt tnt = new CustomPrimedTnt(MegaTntMod.CUSTOM_TNT.get(), level);
        tnt.setPos(x, y, z);
        tnt.setDeltaMovement(vx, vy, vz);
        tnt.xo = x;
        tnt.yo = y;
        tnt.zo = z;
        tnt.configure(MegaTntMod.TNT_BLOCKS.get(type).get().defaultBlockState(), fuse, owner);
        level.addFreshEntity(tnt);
        level.playSound(null, x, y, z, SoundEvents.TNT_PRIMED, SoundSource.BLOCKS, 1.0F, 1.0F);
    }

    @Override
    public void tick() {
        if (this.getFuse() <= 1) {
            // Explode ourselves; vanilla's private explode() would make a normal TNT blast.
            if (!this.level().isClientSide && this.level() instanceof ServerLevel server) {
                if (this.getBlockState().getBlock() instanceof CustomTntBlock block) {
                    TntEffects.detonate(block.getType(), server, this.getX(), this.getY(0.0625D), this.getZ(), this, this.igniter);
                } else {
                    server.explode(this, this.getX(), this.getY(0.0625D), this.getZ(), 4.0F, Level.ExplosionInteraction.TNT);
                }
            }
            this.discard();
            return;
        }
        super.tick();
    }
}
