package com.megatnt;

import java.util.EnumMap;
import java.util.List;
import java.util.Map;

import net.minecraft.ChatFormatting;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.FireBlock;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.ModContainer;
import net.neoforged.fml.common.Mod;
import net.neoforged.fml.config.ModConfig;
import net.neoforged.fml.event.lifecycle.FMLCommonSetupEvent;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.registries.DeferredBlock;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

@Mod(MegaTntMod.MODID)
public class MegaTntMod {
    public static final String MODID = "megatnt";

    public static final DeferredRegister.Blocks BLOCKS = DeferredRegister.createBlocks(MODID);
    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(MODID);
    public static final DeferredRegister<EntityType<?>> ENTITIES = DeferredRegister.create(Registries.ENTITY_TYPE, MODID);
    public static final DeferredRegister<CreativeModeTab> TABS = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, MODID);

    public static final Map<TntType, DeferredBlock<CustomTntBlock>> TNT_BLOCKS = new EnumMap<>(TntType.class);

    static {
        for (TntType type : TntType.values()) {
            DeferredBlock<CustomTntBlock> block = BLOCKS.registerBlock(type.id,
                    props -> new CustomTntBlock(props, type),
                    BlockBehaviour.Properties.of()
                            .mapColor(MapColor.FIRE)
                            .instabreak()
                            .sound(SoundType.GRASS)
                            .ignitedByLava()
                            .isRedstoneConductor((state, level, pos) -> false));
            ITEMS.register(type.id, () -> new BlockItem(block.get(), new Item.Properties()) {
                @Override
                public void appendHoverText(ItemStack stack, Item.TooltipContext context, List<Component> tooltip, TooltipFlag flag) {
                    tooltip.add(Component.translatable("tooltip.megatnt." + type.id).withStyle(ChatFormatting.GRAY));
                }
            });
            TNT_BLOCKS.put(type, block);
        }
    }

    public static final DeferredHolder<EntityType<?>, EntityType<CustomPrimedTnt>> CUSTOM_TNT = ENTITIES.register("custom_tnt",
            () -> EntityType.Builder.<CustomPrimedTnt>of(CustomPrimedTnt::new, MobCategory.MISC)
                    .fireImmune()
                    .sized(0.98F, 0.98F)
                    .eyeHeight(0.15F)
                    .clientTrackingRange(10)
                    .updateInterval(10)
                    .build("custom_tnt"));

    public static final DeferredHolder<CreativeModeTab, CreativeModeTab> TAB = TABS.register("main",
            () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.megatnt"))
                    .icon(() -> new ItemStack(TNT_BLOCKS.get(TntType.NUCLEAR).get()))
                    .displayItems((params, output) -> TNT_BLOCKS.values().forEach(b -> output.accept(b.get())))
                    .build());

    public MegaTntMod(IEventBus modBus, ModContainer container) {
        BLOCKS.register(modBus);
        ITEMS.register(modBus);
        ENTITIES.register(modBus);
        TABS.register(modBus);
        modBus.addListener(this::commonSetup);
        container.registerConfig(ModConfig.Type.COMMON, Config.SPEC);

        NeoForge.EVENT_BUS.addListener(BlockQueue::onServerTick);
        NeoForge.EVENT_BUS.addListener(BlockQueue::onServerStopping);
    }

    private void commonSetup(FMLCommonSetupEvent event) {
        // Let fire ignite our TNT blocks just like vanilla TNT.
        event.enqueueWork(() -> {
            FireBlock fire = (FireBlock) Blocks.FIRE;
            TNT_BLOCKS.values().forEach(b -> fire.setFlammable(b.get(), 15, 100));
        });
    }
}
