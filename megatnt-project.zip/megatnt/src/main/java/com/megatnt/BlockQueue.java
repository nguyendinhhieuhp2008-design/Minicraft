package com.megatnt;

import java.util.ArrayDeque;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.neoforged.neoforge.event.server.ServerStoppingEvent;
import net.neoforged.neoforge.event.tick.ServerTickEvent;

/**
 * Spreads big block changes over several ticks (Config.BLOCKS_PER_TICK per tick) so large
 * explosions don't freeze weaker devices such as phones.
 */
public final class BlockQueue {
    private record Job(ServerLevel level, BlockPos pos, BlockState state) {
    }

    private static final ArrayDeque<Job> JOBS = new ArrayDeque<>();
    private static final int MAX_QUEUE = 200_000;

    private BlockQueue() {
    }

    public static void add(ServerLevel level, BlockPos pos, BlockState state) {
        if (JOBS.size() < MAX_QUEUE) {
            JOBS.add(new Job(level, pos.immutable(), state));
        }
    }

    public static void onServerTick(ServerTickEvent.Post event) {
        int budget = Config.BLOCKS_PER_TICK.get();
        while (budget-- > 0 && !JOBS.isEmpty()) {
            Job job = JOBS.poll();
            if (!job.level().hasChunkAt(job.pos())) {
                continue;
            }
            BlockState current = job.level().getBlockState(job.pos());
            if (!current.isAir() && current.getDestroySpeed(job.level(), job.pos()) < 0) {
                continue; // bedrock etc.
            }
            job.level().setBlock(job.pos(), job.state(), Block.UPDATE_ALL);
        }
    }

    public static void onServerStopping(ServerStoppingEvent event) {
        JOBS.clear();
    }
}
