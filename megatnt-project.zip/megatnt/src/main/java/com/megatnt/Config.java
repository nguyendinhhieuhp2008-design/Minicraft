package com.megatnt;

import net.neoforged.neoforge.common.ModConfigSpec;

/** Common config (config/megatnt-common.toml). Lower the values for weaker phones. */
public final class Config {
    private static final ModConfigSpec.Builder B = new ModConfigSpec.Builder();

    public static final ModConfigSpec.DoubleValue SIZE = B
            .comment("Explosion size multiplier. 0.25 = tiny (phone friendly), 1.0 = default, 2.0 = huge.")
            .defineInRange("sizeMultiplier", 1.0D, 0.25D, 2.0D);

    public static final ModConfigSpec.IntValue BLOCKS_PER_TICK = B
            .comment("Max blocks changed per tick by custom effects. Lower = smoother on phones.")
            .defineInRange("blocksPerTick", 300, 20, 5000);

    public static final ModConfigSpec.IntValue MAX_ENTITIES = B
            .comment("Max entities (TNT, items, fireworks...) spawned by a single explosion.")
            .defineInRange("maxSpawnedEntities", 24, 1, 200);

    public static final ModConfigSpec.BooleanValue PARTICLES = B
            .comment("Extra particles. Disable on weak devices.")
            .define("extraParticles", true);

    public static final ModConfigSpec SPEC = B.build();

    private Config() {
    }
}
